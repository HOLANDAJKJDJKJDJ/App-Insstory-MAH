package com.mah.insstory.MAH;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aghajari.emojiview.*;
import com.facebook.shimmer.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import org.json.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.view.inputmethod.InputMethodManager;

public class ChataiFragmentActivity extends Fragment {
	
	private String TAG = "";
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private ListView listview1;
	private LinearLayout linear3;
	private LinearLayout button;
	private EditText editText;
	private ImageView imageview1;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.chatai_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear2 = _view.findViewById(R.id.linear2);
		linear1 = _view.findViewById(R.id.linear1);
		listview1 = _view.findViewById(R.id.listview1);
		linear3 = _view.findViewById(R.id.linear3);
		button = _view.findViewById(R.id.button);
		editText = _view.findViewById(R.id.editText);
		imageview1 = _view.findViewById(R.id.imageview1);
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listview1.setSelection(listmap.size() - 1);
			}
		});
	}
	
	private void initializeLogic() {
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF404040));
		editText.addTextChangedListener(new TextWatcher() {
			    @Override
			    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				        
				    }
			
			    @Override
			    public void onTextChanged(CharSequence s, int start, int before, int count) {
				        
				    }
			
			    @Override
			    public void afterTextChanged(Editable s) {
				        
				        listview1.post(new Runnable() {
					            @Override
					            public void run() {
						                listview1.setSelection(listmap.size() - 1);
						            }
					        });
				    }
		});
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		listview1.setSelection(listmap.size() - 1);
		TAG = "ChataiFragmentActivity";
		button.setOnClickListener(new View.OnClickListener() {
			            @Override
			            public void onClick(View v) {
				                String inputText = editText.getText().toString();
				                new PostDataTask().execute(inputText);
				
				                
				                HashMap<String, Object> _item = new HashMap<>();
				                _item.put("me", inputText);
				                listmap.add(_item);
				
				                
				                _item = new HashMap<>();
				                _item.put("bot", ""); // Placeholder for bot's message
				                listmap.add(_item);
				
				                
				                listview1.setAdapter(new Listview1Adapter(listmap));
				                ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
				
				                
				                listview1.post(new Runnable() {
					                    @Override
					                    public void run() {
						                        listview1.setSelection(listmap.size() - 1);
						                    }
					                });
				            }
			        });
		
		        
		editText.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        // Check if ListView is already at the last position
				        if (listview1.getLastVisiblePosition() == listmap.size() - 1) {
					            
					            listview1.setSelection(listmap.size() - 1);
					        }
				        return false;
				    }
		});
		                
		        
		    }
	
	    private class PostDataTask extends AsyncTask<String, Void, String> {
		        @Override
		        protected String doInBackground(String... params) {
			            try {
				                URL url = new URL("https://us-central1-conquer-apps-2ad61.cloudfunctions.net/prod/api.live");
				                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
				                connection.setRequestMethod("POST");
				                connection.setRequestProperty("Content-Type", "application/json");
				                connection.setDoInput(true);
				                connection.setDoOutput(true);
				
				                JSONObject jsonObject = new JSONObject();
				                jsonObject.put("n", 1);
				                jsonObject.put("prompt", params[0]);
				                jsonObject.put("temperature", 0.2);
				                jsonObject.put("top_p", 0.2);
				
				                String jsonInputString = jsonObject.toString();
				
				                try (OutputStream os = connection.getOutputStream()) {
					                    byte[] input = jsonInputString.getBytes("utf-8");
					                    os.write(input, 0, input.length);
					                }
				
				                int responseCode = connection.getResponseCode();
				
				                try (BufferedReader br = new BufferedReader(
				                        new InputStreamReader(connection.getInputStream(), "utf-8"))) {
					                    StringBuilder response = new StringBuilder();
					                    String responseLine;
					                    while ((responseLine = br.readLine()) != null) {
						                        response.append(responseLine.trim());
						                    }
					                    return response.toString();
					                }
				            } catch (Exception e) {
				                Log.e(TAG, "Error:", e);
				                return null;
				            }
			        }
		
		        @Override
		        protected void onPostExecute(String response) {
			            if (response != null) {
				                try {
					                    JSONObject jsonResponse = new JSONObject(response);
					                    JSONArray choicesArray = jsonResponse.getJSONArray("choices");
					                    JSONObject firstChoice = choicesArray.getJSONObject(0);
					                    JSONObject messageObject = firstChoice.getJSONObject("message");
					                    String content = messageObject.getString("content");
					
					                    
					                    Map<String, Object> lastItem = listmap.get(listmap.size() - 1);
					                    lastItem.put("bot", content);
					
					                    
					                    ((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
					
					                    
					                    listview1.post(new Runnable() {
						                        @Override
						                        public void run() {
							                            listview1.setSelection(listmap.size() - 1);
							                        }
						                    });
					                } catch (JSONException e) {
					                    Log.e(TAG, "Error parsing JSON", e);
					                }
				            } else {
				                Log.e(TAG, "Response is null");
				            }
			        }
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getActivity().getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.chat_ai, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			if (listmap.get((int)_position).containsKey("me")) {
				textview1.setText(listmap.get((int)_position).get("me").toString());
				LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				        LinearLayout.LayoutParams.WRAP_CONTENT,
				        LinearLayout.LayoutParams.WRAP_CONTENT
				);
				
				params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
				
				linear1.setLayoutParams(params);
				linear2.setVisibility(View.GONE);
				linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, Color.TRANSPARENT));
			}
			if (listmap.get((int)_position).containsKey("bot")) {
				textview1.setText(listmap.get((int)_position).get("bot").toString());
				circleimageview1.setImageResource(R.drawable.icon);
				LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				        LinearLayout.LayoutParams.WRAP_CONTENT,
				        LinearLayout.LayoutParams.WRAP_CONTENT
				);
				
				params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
				
				linear1.setLayoutParams(params);
				linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)25, 0xFF171717));
				textview2.setText("AI Visual");
				linear2.setVisibility(View.VISIBLE);
			}
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					((ClipboardManager) getContext().getSystemService(getContext().getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString()));
				}
			});
			
			return _view;
		}
	}
}