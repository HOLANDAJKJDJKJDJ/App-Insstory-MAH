package com.mah.insstory.MAH;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aghajari.emojiview.*;
import com.facebook.shimmer.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import org.json.*;

public class NewpostBottomdialogFragmentDialogFragmentActivity extends BottomSheetDialogFragment {
	
	public final int REQ_CD_PICK = 101;
	
	private String ReelsPath = "";
	
	private LinearLayout body;
	private LinearLayout top_layout;
	private LinearLayout upload_reels_video;
	private LinearLayout upload_video;
	private LinearLayout create_group;
	private TextView title;
	private ImageView cancel;
	private LinearLayout upload_reels_video_icon_layout;
	private TextView upload_reels_video_title;
	private ImageView upload_reels_video_icon;
	private LinearLayout new_post_icon_layout;
	private TextView new_post_title;
	private ImageView new_post_icon;
	private LinearLayout create_password_group_icon_layout;
	private TextView create_group_title;
	private LinearLayout create_product_premium_icon_layout;
	private ImageView create_password_group_icon;
	
	private Intent intent = new Intent();
	private SharedPreferences lang;
	private Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.newpost_bottomdialog_fragment_dialog_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		body = _view.findViewById(R.id.body);
		top_layout = _view.findViewById(R.id.top_layout);
		upload_reels_video = _view.findViewById(R.id.upload_reels_video);
		upload_video = _view.findViewById(R.id.upload_video);
		create_group = _view.findViewById(R.id.create_group);
		title = _view.findViewById(R.id.title);
		cancel = _view.findViewById(R.id.cancel);
		upload_reels_video_icon_layout = _view.findViewById(R.id.upload_reels_video_icon_layout);
		upload_reels_video_title = _view.findViewById(R.id.upload_reels_video_title);
		upload_reels_video_icon = _view.findViewById(R.id.upload_reels_video_icon);
		new_post_icon_layout = _view.findViewById(R.id.new_post_icon_layout);
		new_post_title = _view.findViewById(R.id.new_post_title);
		new_post_icon = _view.findViewById(R.id.new_post_icon);
		create_password_group_icon_layout = _view.findViewById(R.id.create_password_group_icon_layout);
		create_group_title = _view.findViewById(R.id.create_group_title);
		create_product_premium_icon_layout = _view.findViewById(R.id.create_product_premium_icon_layout);
		create_password_group_icon = _view.findViewById(R.id.create_password_group_icon);
		lang = getContext().getSharedPreferences("lang", Activity.MODE_PRIVATE);
		pick.setType("*/*");
		pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		upload_reels_video.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(pick, REQ_CD_PICK);
			}
		});
		
		upload_video.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getContext().getApplicationContext(), CreatePostActivity.class);
				startActivity(intent);
			}
		});
		
		create_group.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getContext().getApplicationContext(), CreateGroupActivity.class);
				startActivity(intent);
			}
		});
		
		cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dismiss();
			}
		});
	}
	
	private void initializeLogic() {
		title.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/medium.ttf"), 1);
		upload_reels_video_icon_layout.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFEEEEEE));
		new_post_icon_layout.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFEEEEEE));
		create_password_group_icon_layout.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFEEEEEE));
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PICK:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getContext().getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getContext().getApplicationContext(), _data.getData()));
					}
				}
				ReelsPath = _filePath.get((int)(0));
				if (ReelsPath.endsWith(".mp4")) {
					intent.setClass(getContext().getApplicationContext(), ReelsViewerActivity.class);
					intent.putExtra("path", ReelsPath);
					startActivity(intent);
				}
				else {
					SketchwareUtil.showMessage(getContext().getApplicationContext(), "invalid type");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (lang.getString("language", "").equals("")) {
			_TrLang();
		}
		if (lang.getString("language", "").equals("english")) {
			_EnLang();
		}
		if (lang.getString("language", "").equals("indonesia")) {
			_InLang();
		}
	}
	public void _TrLang() {
		title.setText("Oluştur");
		upload_reels_video_title.setText("Reels Videosu Oluştur");
		new_post_title.setText("Gönderi Oluştur");
		
		
		create_group_title.setText("Parolalı Grup Oluştur");
	}
	
	
	public void _EnLang() {
		title.setText("Create");
		upload_reels_video_title.setText("Create Reels Video");
		new_post_title.setText("New Post");
		create_group_title.setText("Create Group with Password");
	}
	
	
	public void _InLang() {
		title.setText("Buat");
		upload_reels_video_title.setText("Buat Video Reels");
		new_post_title.setText("Postingan Baru");
		
		
		create_group_title.setText("Buat Grup");
	}
	
	
	public void _ar() {
		title.setText("إنشاء ");
		upload_reels_video_title.setText("انشاء ريلز");
		new_post_title.setText("إنشاء منشور");
		create_group_title.setText("إنشاء مجموعة ");
	}
	
	
	public void _language() {
		if (lang.getString("language", "").equals("ar")) {
			_ar();
		}
		if (lang.getString("language", "").equals("english")) {
			_EnLang();
		}
	}
	
}