package com.mah.insstory.MAH;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aghajari.emojiview.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import org.json.*;
import com.aghajari.emojiview.view.AXEmojiTextView;
import com.aghajari.emojiview.view.AXEmojiEditText;
import com.aghajari.emojiview.view.AXEmojiPopupLayout;
import com.aghajari.emojiview.view.AXEmojiView;
import com.aghajari.emojiview.AXEmojiManager;
import com.aghajari.emojiview.AXEmojiUtils;
import com.aghajari.emojiview.emoji.iosprovider.AXIOSEmoji;
import com.aghajari.emojiview.emoji.iosprovider.AXIOSEmojiLoader;
import com.aghajari.emojiview.emoji.iosprovider.AXIOSEmojiProvider;
import com.aghajari.emojiview.view.AXEmojiPager;
import com.aghajari.emojiview.AXEmojiTheme;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;

public class ChatActivity extends AppCompatActivity {
	
	public final int REQ_CD_IMG = 101;
	public final int REQ_CD_DOC = 102;
	public final int REQ_CD_MUSIK = 103;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private String key = "";
	private String chatroom = "";
	private String chatcopy = "";
	private String mkey = "";
	private String first = "";
	private double more_tools = 0;
	private String typingview = "";
	private String typingcopy = "";
	private String EditKey = "";
	private String ReplyedKey = "";
	private boolean ReplyedBoolean = false;
	private boolean ChildAdded = false;
	private double limit = 0;
	private double AudioTime = 0;
	private boolean AudioRecording = false;
	private String AudioPath = "";
	private String audioUrl = "";
	private double position_ = 0;
	private String audioTime = "";
	private String AudioName = "";
	private String AudioPath2 = "";
	private double tm_difference = 0;
	private String SetTimeAsecond = "";
	private String SetTimeSecond = "";
	private String SetTimeAMinute = "";
	private String SetTimeMinute = "";
	private String SetTimeHours = "";
	private String SetTimeDays = "";
	private String OnlineStatus = "";
	private String OfflineStatus = "";
	private String TypingStatus = "";
	private String AudioErrorL = "";
	private String AudioMinute = "";
	private String AudioSecond = "";
	private String videocall = "";
	private String messagecopyed = "";
	private String block_s = "";
	private String report_s = "";
	private String emptymessage = "";
	private String edited = "";
	private String uploading_audio = "";
	private String uploading_image = "";
	private String encTs = "";
	private HashMap<String, Object> UserProfile = new HashMap<>();
	private double ChatSize = 0;
	private String ReplyedMessage = "";
	private String ReplyedMessageUid = "";
	private String SecondName = "";
	private String FirstName = "";
	private HashMap<String, Object> UserName = new HashMap<>();
	private String RecordingString = "";
	private String YouReplyTo = "";
	private String YES = "";
	private String NO = "";
	private String DeleteMessageDialogTitle = "";
	private String DeleteMessageDialogMessage = "";
	private String MessagePopupEdit = "";
	private String MessagePopupReply = "";
	private String MessagePopupCopy = "";
	private String MessagePopupDelete = "";
	private String ddd = "";
	private String inboxx = "";
	private String count = "";
	private double pushAadT = 0;
	private boolean isPlaying = false;
	private double menit = 0;
	private double detik = 0;
	private double Audio = 0;
	private String push = "";
	private String rekam = "";
	private String waktu = "";
	private String DocName = "";
	private String DocPath = "";
	private String FilePath = "";
	private double Sizefile = 0;
	private double B = 0;
	private double KB = 0;
	private double MB = 0;
	private double GB = 0;
	private double TB = 0;
	private double PB = 0;
	private String returnedSize = "";
	private String format = "";
	private String ImagePath = "";
	private String ImageName = "";
	private boolean SendimgD = false;
	private boolean SendImgD = false;
	private boolean isShow = false;
	private HashMap<String, Object> mp = new HashMap<>();
	private HashMap<String, Object> maa = new HashMap<>();
	private HashMap<String, Object> mahmoudBlok = new HashMap<>();
	private String token = "";
	private String URL = "";
	private String Server_key = "";
	private HashMap<String, Object> HEADERS = new HashMap<>();
	private HashMap<String, Object> BODY = new HashMap<>();
	private HashMap<String, Object> Notification_BODY = new HashMap<>();
	private HashMap<String, Object> User_Token = new HashMap<>();
	private HashMap<String, Object> User_Img_Url = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<String> str = new ArrayList<>();
	
	private LinearLayout base;
	private LinearLayout body;
	private AXEmojiPopupLayout layout;
	private LinearLayout top;
	private LinearLayout medium;
	private ImageView back;
	private LinearLayout profile;
	private LinearLayout linear3;
	private ImageView more_button;
	private CircleImageView avatar;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView status;
	private TextView username;
	private ImageView verified;
	private ProgressBar loader;
	private TextView textview1;
	private TextView token_user;
	private TextView img_user_url;
	private ListView messages;
	private LinearLayout typing_layout;
	private LinearLayout bottom;
	private TextView typing_txt;
	private LinearLayout warning_layout;
	private LinearLayout message_body;
	private TextView warning;
	private LinearLayout message_body_in_reply;
	private LinearLayout category;
	private LinearLayout sound_record_body;
	private LinearLayout message_body_in_message;
	private ImageView message_body_in_reply_cancel;
	private LinearLayout message_body_in_reply_chld;
	private TextView message_body_in_reply_title;
	private TextView message_body_in_reply_text;
	private LinearLayout image;
	private LinearLayout file;
	private LinearLayout music;
	private ImageView image_icon;
	private TextView image_title;
	private ImageView file_icon;
	private TextView file_title;
	private ImageView music_icon;
	private TextView music_title;
	private ImageView sound_record_cancel;
	private TextView recording_text;
	private ImageView send_audio;
	private ImageView media;
	private ImageView imageview1;
	private LinearLayout msg_spc;
	private EditText message;
	private ImageView sound;
	private ImageView send;
	
	private DatabaseReference chat1 = _firebase.getReference("+chatroom+");
	private ChildEventListener _chat1_child_listener;
	private DatabaseReference chat2 = _firebase.getReference("+chatcopy+");
	private ChildEventListener _chat2_child_listener;
	private Calendar cc = Calendar.getInstance();
	private Intent i = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference ms = _firebase.getReference("inbox");
	private ChildEventListener _ms_child_listener;
	private SharedPreferences lang;
	private DatabaseReference udb = _firebase.getReference("users");
	private ChildEventListener _udb_child_listener;
	private SharedPreferences save;
	private MediaPlayer audio;
	private TimerTask rc_time;
	private Vibrator vibrate;
	private SpeechRecognizer speak;
	private TimerTask audiotimer;
	private Intent intent = new Intent();
	private ObjectAnimator o = new ObjectAnimator();
	private TimerTask poPup;
	private Calendar ct = Calendar.getInstance();
	private Calendar time2 = Calendar.getInstance();
	private DatabaseReference notification = _firebase.getReference("notification");
	private ChildEventListener _notification_child_listener;
	private DatabaseReference typing1 = _firebase.getReference("+typing+");
	private ChildEventListener _typing1_child_listener;
	private DatabaseReference typing2 = _firebase.getReference("+typingcopy+");
	private ChildEventListener _typing2_child_listener;
	private StorageReference sdb = _firebase_storage.getReference("chat/sound");
	private OnCompleteListener<Uri> _sdb_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _sdb_download_success_listener;
	private OnSuccessListener _sdb_delete_success_listener;
	private OnProgressListener _sdb_upload_progress_listener;
	private OnProgressListener _sdb_download_progress_listener;
	private OnFailureListener _sdb_failure_listener;
	
	private ProgressDialog progd;
	private StorageReference idb = _firebase_storage.getReference("chat/images");
	private OnCompleteListener<Uri> _idb_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _idb_download_success_listener;
	private OnSuccessListener _idb_delete_success_listener;
	private OnProgressListener _idb_upload_progress_listener;
	private OnProgressListener _idb_download_progress_listener;
	private OnFailureListener _idb_failure_listener;
	
	private RequestNetwork rq;
	private RequestNetwork.RequestListener _rq_request_listener;
	private Intent img = new Intent(Intent.ACTION_GET_CONTENT);
	private DatabaseReference inbox = _firebase.getReference("+inbox+");
	private ChildEventListener _inbox_child_listener;
	private Intent doc = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent musik = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fdb = _firebase_storage.getReference("chat/files");
	private OnCompleteListener<Uri> _fdb_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fdb_download_success_listener;
	private OnSuccessListener _fdb_delete_success_listener;
	private OnProgressListener _fdb_upload_progress_listener;
	private OnProgressListener _fdb_download_progress_listener;
	private OnFailureListener _fdb_failure_listener;
	
	private AlertDialog.Builder dialog;
	private DatabaseReference t = _firebase.getReference("t");
	private ChildEventListener _t_child_listener;
	private RequestNetwork RQ;
	private RequestNetwork.RequestListener _RQ_request_listener;
	
	private OnCompleteListener Cm_onCompleteListener;
	private MediaPlayer send_message;
	private MediaPlayer specer;
	private MediaPlayer img_pslyer;
	private MediaPlayer file_player;
	private MediaPlayer typing_player;
	private MediaPlayer hnak;
	private AlertDialog.Builder de;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECORD_AUDIO}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		base = findViewById(R.id.base);
		body = findViewById(R.id.body);
		layout = findViewById(R.id.layout);
		top = findViewById(R.id.top);
		medium = findViewById(R.id.medium);
		back = findViewById(R.id.back);
		profile = findViewById(R.id.profile);
		linear3 = findViewById(R.id.linear3);
		more_button = findViewById(R.id.more_button);
		avatar = findViewById(R.id.avatar);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		status = findViewById(R.id.status);
		username = findViewById(R.id.username);
		verified = findViewById(R.id.verified);
		loader = findViewById(R.id.loader);
		textview1 = findViewById(R.id.textview1);
		token_user = findViewById(R.id.token_user);
		img_user_url = findViewById(R.id.img_user_url);
		messages = findViewById(R.id.messages);
		typing_layout = findViewById(R.id.typing_layout);
		bottom = findViewById(R.id.bottom);
		typing_txt = findViewById(R.id.typing_txt);
		warning_layout = findViewById(R.id.warning_layout);
		message_body = findViewById(R.id.message_body);
		warning = findViewById(R.id.warning);
		message_body_in_reply = findViewById(R.id.message_body_in_reply);
		category = findViewById(R.id.category);
		sound_record_body = findViewById(R.id.sound_record_body);
		message_body_in_message = findViewById(R.id.message_body_in_message);
		message_body_in_reply_cancel = findViewById(R.id.message_body_in_reply_cancel);
		message_body_in_reply_chld = findViewById(R.id.message_body_in_reply_chld);
		message_body_in_reply_title = findViewById(R.id.message_body_in_reply_title);
		message_body_in_reply_text = findViewById(R.id.message_body_in_reply_text);
		image = findViewById(R.id.image);
		file = findViewById(R.id.file);
		music = findViewById(R.id.music);
		image_icon = findViewById(R.id.image_icon);
		image_title = findViewById(R.id.image_title);
		file_icon = findViewById(R.id.file_icon);
		file_title = findViewById(R.id.file_title);
		music_icon = findViewById(R.id.music_icon);
		music_title = findViewById(R.id.music_title);
		sound_record_cancel = findViewById(R.id.sound_record_cancel);
		recording_text = findViewById(R.id.recording_text);
		send_audio = findViewById(R.id.send_audio);
		media = findViewById(R.id.media);
		imageview1 = findViewById(R.id.imageview1);
		msg_spc = findViewById(R.id.msg_spc);
		message = findViewById(R.id.message);
		sound = findViewById(R.id.sound);
		send = findViewById(R.id.send);
		auth = FirebaseAuth.getInstance();
		lang = getSharedPreferences("lang", Activity.MODE_PRIVATE);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		vibrate = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		speak = SpeechRecognizer.createSpeechRecognizer(this);
		rq = new RequestNetwork(this);
		img.setType("image/*");
		img.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		doc.setType("*/*");
		doc.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		musik.setType("audio/*");
		musik.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		dialog = new AlertDialog.Builder(this);
		RQ = new RequestNetwork(this);
		de = new AlertDialog.Builder(this);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				map = new HashMap<>();
				map.put("typing", "false");
				typing2.child("typing_status").updateChildren(map);
				map.clear();
				chat1.removeEventListener(_chat1_child_listener);
				chat2.removeEventListener(_chat2_child_listener);
				finish();
			}
		});
		
		profile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				message.setText("");
				chat1.removeEventListener(_chat1_child_listener);
				chat2.removeEventListener(_chat2_child_listener);
				i.setClass(getApplicationContext(), ProfileActivity.class);
				i.putExtra("uid", getIntent().getStringExtra("seconduser"));
				startActivity(i);
			}
		});
		
		more_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog ChatMenu = new com.google.android.material.bottomsheet.BottomSheetDialog(ChatActivity.this);
				View ChatMenuV = getLayoutInflater().inflate(R.layout.chat_more_button_custom, null);
				ChatMenu.setContentView(ChatMenuV);
				
				final LinearLayout linear  = (LinearLayout)ChatMenuV.findViewById(R.id.body);
				
				ChatMenu.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				
				ChatMenu.show();
				android.graphics.drawable.GradientDrawable CM = new android.graphics.drawable.GradientDrawable();
				int dc = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				CM.setColor(0xFFFFFFFF);
				CM.setCornerRadii(new float[]{
						dc*15,dc*15,dc*15 ,dc*15,dc*0,dc*0 ,dc*0,dc*0});
				linear.setElevation(dc*5);
				android.graphics.drawable.RippleDrawable ChatMenuDG = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), CM, null);
				linear.setBackground(ChatMenuDG);
				LinearLayout slider = (LinearLayout) ChatMenuV.findViewById(R.id.slider);
				TextView block_text = ChatMenuV.findViewById(R.id.block_text);
				TextView report_text = ChatMenuV.findViewById(R.id.report_text);
				LinearLayout block = ChatMenuV.findViewById(R.id.block);
				LinearLayout report = ChatMenuV.findViewById(R.id.report);
				LinearLayout body = ChatMenuV.findViewById(R.id.body);
				block_text.setText(block_s);
				report_text.setText(report_s);
				slider.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF424242));
				_rippleRoundStroke(block, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				_rippleRoundStroke(report, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				block.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						dialog.setTitle("Are you sure?");
						dialog.setMessage("want to block ".concat("\"".concat(FirebaseAuth.getInstance().getCurrentUser().getEmail().concat("\" ?"))));
						dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								SketchwareUtil.showMessage(getApplicationContext(), "successful");
								mahmoudBlok = new HashMap<>();
								mahmoudBlok.put("hzr", "true");
								t.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(mahmoudBlok);
								mahmoudBlok.clear();
							}
						});
						dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
						dialog.create().show();
						ChatMenu.dismiss();
					}
				});
				report.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						save.edit().putString("LastReportUid", getIntent().getStringExtra("seconduser")).commit();
						ReportUserBottomdialogFragmentDialogFragmentActivityN = new ReportUserBottomdialogFragmentDialogFragmentActivity();
						ReportUserBottomdialogFragmentDialogFragmentActivityN.show(getSupportFragmentManager(),"1");
						ChatMenu.dismiss();
					}
				});
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				dialog.setTitle("Are you sure?");
				dialog.setMessage("want to block ".concat("\"".concat(username.getText().toString().concat("\" ?"))));
				dialog.setMessage("want to block ".concat("\"".concat(FirebaseAuth.getInstance().getCurrentUser().getEmail().concat("\" ?"))));
				dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), "successful");
						mahmoudBlok = new HashMap<>();
						mahmoudBlok.put("hzr", "false");
						t.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(mahmoudBlok);
						mahmoudBlok.clear();
					}
				});
				dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
			}
		});
		
		messages.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				final com.google.android.material.bottomsheet.BottomSheetDialog MessageMenu = new com.google.android.material.bottomsheet.BottomSheetDialog(ChatActivity.this);
				View MessageMenuV = getLayoutInflater().inflate(R.layout.message_setting_popup, null);
				MessageMenu.setContentView(MessageMenuV);
				
				final LinearLayout linear  = (LinearLayout)MessageMenuV.findViewById(R.id.body);
				
				MessageMenu.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				
				MessageMenu.show();
				
				android.graphics.drawable.GradientDrawable MM = new android.graphics.drawable.GradientDrawable();
				int dec = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				MM.setColor(0xFFFFFFFF);
				MM.setCornerRadii(new float[]{
						dec*15,dec*15,dec*15 ,dec*15,dec*0,dec*0 ,dec*0,dec*0});
				linear.setElevation(dec*5);
				android.graphics.drawable.RippleDrawable MessageMenuDG = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), MM, null);
				linear.setBackground(MessageMenuDG);
				TextView edit_title = (TextView) MessageMenuV.findViewById(R.id.edit_title);
				TextView reply_title = (TextView) MessageMenuV.findViewById(R.id.reply_title);
				TextView copy_title = (TextView) MessageMenuV.findViewById(R.id.copy_title);
				TextView delete_title = (TextView) MessageMenuV.findViewById(R.id.delete_title);
				LinearLayout slider = (LinearLayout) MessageMenuV.findViewById(R.id.slider);
				LinearLayout edit = (LinearLayout) MessageMenuV.findViewById(R.id.edit);
				LinearLayout reply = (LinearLayout) MessageMenuV.findViewById(R.id.reply);
				LinearLayout copy = (LinearLayout) MessageMenuV.findViewById(R.id.copy);
				LinearLayout delete = (LinearLayout) MessageMenuV.findViewById(R.id.delete);
				edit_title.setText(MessagePopupEdit);
				reply_title.setText(MessagePopupReply);
				copy_title.setText(MessagePopupCopy);
				delete_title.setText(MessagePopupDelete);
				slider.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF757575));
				_rippleRoundStroke(edit, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				_rippleRoundStroke(reply, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				_rippleRoundStroke(copy, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				_rippleRoundStroke(delete, "#FFFFFF", "#EEEEEE", 0, 0, "#FFFFFF");
				if (save.getString("mypremium", "").equals("free")) {
					if (listmap.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (listmap.get((int)_position).get("message_type").toString().equals("MSG")) {
							edit.setVisibility(View.GONE);
							reply.setVisibility(View.VISIBLE);
							copy.setVisibility(View.VISIBLE);
							delete.setVisibility(View.VISIBLE);
						}
						else {
							if (listmap.get((int)_position).get("message_type").toString().equals("AUDIO")) {
								edit.setVisibility(View.GONE);
								reply.setVisibility(View.VISIBLE);
								copy.setVisibility(View.GONE);
								delete.setVisibility(View.VISIBLE);
							}
							else {
								if (listmap.get((int)_position).get("message_type").toString().equals("IMG")) {
									edit.setVisibility(View.GONE);
									reply.setVisibility(View.VISIBLE);
									copy.setVisibility(View.GONE);
									delete.setVisibility(View.VISIBLE);
								}
							}
						}
					}
					else {
						if (listmap.get((int)_position).get("message_type").toString().equals("MSG")) {
							edit.setVisibility(View.GONE);
							reply.setVisibility(View.VISIBLE);
							copy.setVisibility(View.VISIBLE);
							delete.setVisibility(View.GONE);
						}
						else {
							if (listmap.get((int)_position).get("message_type").toString().equals("AUDIO")) {
								edit.setVisibility(View.GONE);
								reply.setVisibility(View.VISIBLE);
								copy.setVisibility(View.GONE);
								delete.setVisibility(View.GONE);
							}
							else {
								if (listmap.get((int)_position).get("message_type").toString().equals("IMG")) {
									edit.setVisibility(View.GONE);
									reply.setVisibility(View.VISIBLE);
									copy.setVisibility(View.GONE);
									delete.setVisibility(View.GONE);
								}
							}
						}
					}
				}
				else {
					if (listmap.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (listmap.get((int)_position).get("message_type").toString().equals("MSG")) {
							edit.setVisibility(View.GONE);
							reply.setVisibility(View.VISIBLE);
							copy.setVisibility(View.VISIBLE);
							delete.setVisibility(View.VISIBLE);
						}
						else {
							if (listmap.get((int)_position).get("message_type").toString().equals("AUDIO")) {
								edit.setVisibility(View.GONE);
								reply.setVisibility(View.VISIBLE);
								copy.setVisibility(View.GONE);
								delete.setVisibility(View.VISIBLE);
							}
							else {
								if (listmap.get((int)_position).get("message_type").toString().equals("IMG")) {
									edit.setVisibility(View.GONE);
									reply.setVisibility(View.VISIBLE);
									copy.setVisibility(View.GONE);
									delete.setVisibility(View.VISIBLE);
								}
							}
						}
					}
					else {
						if (listmap.get((int)_position).get("message_type").toString().equals("MSG")) {
							edit.setVisibility(View.GONE);
							reply.setVisibility(View.VISIBLE);
							copy.setVisibility(View.VISIBLE);
							delete.setVisibility(View.VISIBLE);
						}
						else {
							if (listmap.get((int)_position).get("message_type").toString().equals("AUDIO")) {
								edit.setVisibility(View.GONE);
								reply.setVisibility(View.VISIBLE);
								copy.setVisibility(View.GONE);
								delete.setVisibility(View.VISIBLE);
							}
							else {
								if (listmap.get((int)_position).get("message_type").toString().equals("IMG")) {
									edit.setVisibility(View.GONE);
									reply.setVisibility(View.VISIBLE);
									copy.setVisibility(View.GONE);
									delete.setVisibility(View.VISIBLE);
								}
							}
						}
					}
				}
				reply.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						ReplyedBoolean = true;
						ReplyedMessageUid = listmap.get((int)_position).get("uid").toString();
						if (listmap.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							message_body_in_reply_title.setText(YouReplyTo.concat(UserName.get(getIntent().getStringExtra("firstuser")).toString()));
						}
						else {
							message_body_in_reply_title.setText(YouReplyTo.concat(UserName.get(getIntent().getStringExtra("seconduser")).toString()));
						}
						message_body_in_reply.setVisibility(View.VISIBLE);
						MessageMenu.dismiss();
						if (listmap.get((int)_position).get("message_type").toString().equals("MSG")) {
							ReplyedMessage = listmap.get((int)_position).get("message").toString();
							message_body_in_reply_text.setText(ReplyedMessage);
						}
						else {
							if (listmap.get((int)_position).get("message_type").toString().equals("AUDIO")) {
								ReplyedMessage = "AUDIO";
								message_body_in_reply_text.setText("AUDIO");
							}
							else {
								if (listmap.get((int)_position).get("message_type").toString().equals("IMG")) {
									ReplyedMessage = "IMAGE";
									message_body_in_reply_text.setText("IMAGE");
								}
							}
						}
					}
				});
				copy.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", listmap.get((int)_position).get("message").toString()));
						SketchwareUtil.showMessage(getApplicationContext(), messagecopyed);
						MessageMenu.dismiss();
					}
				});
				delete.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						save.edit().putString("LastDeleteMessageKey", listmap.get((int)_position).get("mkey").toString()).commit();
						_DeleteMessageDialog(DeleteMessageDialogTitle, DeleteMessageDialogMessage, YES, NO, true);
						MessageMenu.dismiss();
					}
				});
				edit.setVisibility(View.GONE);
			}
		});
		
		messages.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				de.setTitle("تاكيد");
				de.setMessage("هل تريد حذف الرسالة");
				de.setPositiveButton("نعم", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						udb.child(listmap.get((int)_position).get("message").toString()).removeValue();
					}
				});
				de.setNegativeButton("لا", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				de.create().show();
				return true;
			}
		});
		
		message_body_in_reply_cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ReplyedBoolean = false;
				message_body_in_reply.setVisibility(View.GONE);
			}
		});
		
		image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(img, REQ_CD_IMG);
			}
		});
		
		file.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(doc, REQ_CD_DOC);
			}
		});
		
		music.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(musik, REQ_CD_MUSIK);
			}
		});
		
		sound_record_cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (!AudioRecording) {
					rc_time.cancel();
					try {
						
						myAudioRecorder.stop();
						myAudioRecorder.release();
						myAudioRecorder = null;
						
					} catch(Exception e) {}
					AudioRecording = true;
					message_body_in_reply.setVisibility(View.GONE);
					message_body_in_message.setVisibility(View.VISIBLE);
					sound_record_body.setVisibility(View.GONE);
					AudioTime = 0;
				}
			}
		});
		
		send_audio.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				rc_time.cancel();
				try {
					
					myAudioRecorder.stop();
					myAudioRecorder.release();
					myAudioRecorder = null;
					
				} catch(Exception e) {}
				message_body_in_reply.setVisibility(View.GONE);
				sound_record_body.setVisibility(View.GONE);
				message_body_in_message.setVisibility(View.VISIBLE);
				pushAadT = AudioTime;
				AudioName = udb.push().getKey().concat(".mp3");
				sdb.child(AudioName).putFile(Uri.fromFile(new File(AudioPath))).addOnFailureListener(_sdb_failure_listener).addOnProgressListener(_sdb_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return sdb.child(AudioName).getDownloadUrl();
					}}).addOnCompleteListener(_sdb_upload_success_listener);
				progd = new ProgressDialog(ChatActivity.this);
				progd.setMessage("Uploading Audio to server");
				progd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
				progd.show();
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					HEADERS = new HashMap<>();
					HEADERS.put("Authorization", "key=".concat(Server_key));
					HEADERS.put("Content-Type", "application/json");
					Notification_BODY = new HashMap<>();
					Notification_BODY.put("body", recording_text.getText().toString());
					Notification_BODY.put("title", username.getText().toString());
					Notification_BODY.put("image", img_user_url.getText().toString());
					BODY = new HashMap<>();
					BODY.put("to", token_user.getText().toString());
					SketchwareUtil.showMessage(getApplicationContext(), "Sending To FCM TOKEN");
					BODY.put("notification", Notification_BODY);
					RQ.setHeaders(HEADERS);
					RQ.setParams(BODY, RequestNetworkController.REQUEST_BODY);
					RQ.startRequestNetwork(RequestNetworkController.POST, URL, "A", _RQ_request_listener);
				}
				else {
					
				}
			}
		});
		
		media.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(doc, REQ_CD_DOC);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				isShow = layout.isShowing();
				if (isShow) {
					layout.hideAndOpenKeyboard();
					imageview1.setImageResource(R.drawable.ic_insert_emoticon_black);
					layout.setVisibility(View.GONE);
				}
				else {
					layout.toggle();
					layout.show();
					imageview1.setImageResource(R.drawable.ic_keyboard_black);
					layout.setVisibility(View.VISIBLE);
				}
			}
		});
		
		message.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				layout.setVisibility(View.GONE);
			}
		});
		
		message.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (message.getText().toString().equals("")) {
					sound.setVisibility(View.VISIBLE);
					send.setVisibility(View.GONE);
					map = new HashMap<>();
					map.put("typing", "false");
					typing2.child("typing_status").updateChildren(map);
					map.clear();
				}
				else {
					sound.setVisibility(View.GONE);
					send.setVisibility(View.VISIBLE);
					map = new HashMap<>();
					map.put("typing", "true");
					typing2.child("typing_status").updateChildren(map);
					map.clear();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		sound.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (AudioRecording) {
					specer = MediaPlayer.create(getApplicationContext(), R.raw.cei);
					specer.start();
					if (AudioTime < 10) {
						rekam = " 0.0";
					}
					else {
						rekam = " 0.";
					}
					rc_time = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									AudioTime++;
									recording_text.setText(RecordingString.concat(rekam.concat(String.valueOf((long)(AudioTime)))));
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(rc_time, (int)(0), (int)(1000));
					sound_record_body.setVisibility(View.VISIBLE);
					message_body_in_reply.setVisibility(View.GONE);
					message_body_in_message.setVisibility(View.GONE);
					vibrate.vibrate((long)(100));
					myAudioRecorder = new MediaRecorder();
					
					myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
					
					myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
					
					myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
					
					myAudioRecorder.setOutputFile(AudioPath);
					try {
						
						myAudioRecorder.prepare();
						myAudioRecorder.start();
						
					} catch (Exception e) {}
					AudioRecording = false;
				}
			}
		});
		
		send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (message.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), emptymessage);
				}
				else {
					send_message = MediaPlayer.create(getApplicationContext(), R.raw.app_src_main_res_raw_sound_in);
					send_message.start();
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						HEADERS = new HashMap<>();
						HEADERS.put("Authorization", "key=".concat(Server_key));
						HEADERS.put("Content-Type", "application/json");
						Notification_BODY = new HashMap<>();
						Notification_BODY.put("body", message.getText().toString());
						Notification_BODY.put("title", username.getText().toString());
						Notification_BODY.put("image", img_user_url.getText().toString());
						BODY = new HashMap<>();
						BODY.put("to", token_user.getText().toString());
						SketchwareUtil.showMessage(getApplicationContext(), "Sending To FCM TOKEN");
						BODY.put("notification", Notification_BODY);
						RQ.setHeaders(HEADERS);
						RQ.setParams(BODY, RequestNetworkController.REQUEST_BODY);
						RQ.startRequestNetwork(RequestNetworkController.POST, URL, "A", _RQ_request_listener);
					}
					else {
						
					}
					mkey = chat1.push().getKey();
					cc = Calendar.getInstance();
					map = new HashMap<>();
					map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("message", message.getText().toString());
					map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
					map.put("message_type", "MSG");
					map.put("edited", "false");
					if (ReplyedBoolean) {
						map.put("replyed_message", ReplyedMessage);
						map.put("replyed_message_uid", ReplyedMessageUid);
					}
					map.put("mkey", mkey);
					map.put("message_status", "forwarded");
					chat1.child(mkey).updateChildren(map);
					chat2.child(mkey).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("uid", getIntent().getStringExtra("seconduser"));
					map.put("lastMessage", message.getText().toString());
					map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
					map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
					map.put("read", "null");
					ms.child(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser")))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("uid", getIntent().getStringExtra("firstuser"));
					map.put("lastMessage", message.getText().toString());
					map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
					map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
					map.put("read", "null");
					ms.child(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser")))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("typing", "false");
					typing2.child("typing_status").updateChildren(map);
					map.clear();
					message.setText("");
					message_body_in_reply.setVisibility(View.GONE);
					ReplyedBoolean = false;
				}
			}
		});
		
		_chat1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				ChildAdded = true;
				map = new HashMap<>();
				map.put("message_status", "seen");
				chat2.child(_childValue.get("mkey").toString()).updateChildren(map);
				map.clear();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat1.addChildEventListener(_chat1_child_listener);
		
		_chat2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat2.addChildEventListener(_chat2_child_listener);
		
		_ms_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		ms.addChildEventListener(_ms_child_listener);
		
		_udb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				loader.setVisibility(View.GONE);
				Intent userService = new Intent(ChatActivity.this, UserStatus.class);
					startService(userService);
				if (_childValue.containsKey("uid") && _childValue.containsKey("avatar")) {
					UserProfile.put(_childValue.get("uid").toString(), _childValue.get("avatar").toString());
				}
				if (_childValue.containsKey("uid") && _childValue.containsKey("yourname")) {
					UserName.put(_childValue.get("uid").toString(), _childValue.get("yourname").toString());
				}
				if (_childValue.containsKey("uid") && _childValue.containsKey("tokn_user")) {
					User_Token.put(_childValue.get("uid").toString(), _childValue.get("tokn_user").toString());
				}
				if (_childValue.containsKey("uid") && _childValue.containsKey("img_user")) {
					User_Img_Url.put(_childValue.get("uid").toString(), _childValue.get("img_user").toString());
				}
				if (_childKey.equals(getIntent().getStringExtra("seconduser"))) {
					typing_txt.setText("●●●    ".concat(_childValue.get("username").toString().concat(TypingStatus)));
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(avatar);
					username.setText(_childValue.get("username").toString());
					token_user.setText(_childValue.get("tokn_user").toString());
					img_user_url.setText(_childValue.get("img_user").toString());
					if (_childValue.get("verify").toString().equals("blue")) {
						verified.setImageResource(R.drawable.blue_verified);
						verified.setVisibility(View.VISIBLE);
					}
					else {
						if (_childValue.get("verify").toString().equals("red")) {
							verified.setImageResource(R.drawable.red_verified);
							verified.setVisibility(View.VISIBLE);
						}
						else {
							if (_childValue.get("verify").toString().equals("false")) {
								verified.setVisibility(View.GONE);
							}
						}
					}
					if (_childValue.get("blocked").toString().equals("true")) {
						warning_layout.setVisibility(View.VISIBLE);
						message_body.setVisibility(View.GONE);
					}
					else {
						if (_childValue.get("blocked").toString().equals("false")) {
							warning_layout.setVisibility(View.GONE);
							message_body.setVisibility(View.VISIBLE);
						}
					}
					if (_childValue.get("online").toString().equals("true")) {
						status.setText(OnlineStatus);
						status.setTextColor(0xFF4CAF50);
					}
					else {
						if (_childValue.get("online").toString().equals("false")) {
							status.setText(OfflineStatus);
							status.setTextColor(0xFFF44336);
						}
						else {
							_setTime(Double.parseDouble(_childValue.get("online").toString()), status);
							status.setTextColor(0xFFF44336);
						}
					}
					if (_childValue.get("story").toString().equals("true")) {
						avatar.setBackgroundResource(R.drawable.story_profile);
						avatar.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								i.setClass(getApplicationContext(), StoryviewActivity.class);
								i.putExtra("uid", getIntent().getStringExtra("seconduser"));
								startActivity(i);
							}
						});
					}
					else {
						if (_childValue.get("story").toString().equals("false")) {
							avatar.setBackgroundResource(0);
							avatar.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
									i.setClass(getApplicationContext(), ProfileActivity.class);
									i.putExtra("uid", getIntent().getStringExtra("seconduser"));
									startActivity(i);
								}
							});
						}
					}
				}
				ChatSize = 40;
				query = chat1.limitToLast((int)ChatSize);
				query.addValueEventListener(valueEventListener1);
			}
			com.google.firebase.database.Query query;
			
			ValueEventListener valueEventListener1 = new ValueEventListener() {
				@Override public void onDataChange(DataSnapshot _param1) {
					try {
						str.clear();
						listmap.clear();
						GenericTypeIndicator < HashMap< String, Object>> _ind = new GenericTypeIndicator<HashMap< String, Object>>() {};
						
						for (DataSnapshot _data : _param1.getChildren()) {
							str.add(_data.getKey());
							HashMap <String, Object> _map= _data.getValue(_ind);
							listmap.add(_map); }
						messages.setAdapter(new MessagesAdapter(listmap));
						((BaseAdapter)messages.getAdapter()).notifyDataSetChanged();
					} catch (Exception e) { showMessage(e.toString()); } }
				@Override public void onCancelled(DatabaseError databaseError) { } }; {
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("blocked").toString().equals("true")) {
						
						startActivity(intent);
					}
				}
				if (_childKey.equals(getIntent().getStringExtra("seconduser"))) {
					if (_childValue.get("online").toString().equals("true")) {
						status.setText(OnlineStatus);
						status.setTextColor(0xFF4CAF50);
					}
					else {
						typing_layout.setVisibility(View.GONE);
						if (_childValue.get("online").toString().equals("false")) {
							status.setText(OfflineStatus);
							status.setTextColor(0xFFF44336);
						}
						else {
							_setTime(Double.parseDouble(_childValue.get("online").toString()), status);
							status.setTextColor(0xFFF44336);
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		udb.addChildEventListener(_udb_child_listener);
		
		_notification_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		notification.addChildEventListener(_notification_child_listener);
		
		_typing1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("typing").toString().equals("true")) {
					typing_player = MediaPlayer.create(getApplicationContext(), R.raw.livechat29007);
					typing_player.start();
					typing_layout.setVisibility(View.VISIBLE);
				}
				else {
					typing_layout.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("typing").toString().equals("true")) {
					typing_player = MediaPlayer.create(getApplicationContext(), R.raw.livechat29007);
					typing_player.start();
					typing_layout.setVisibility(View.VISIBLE);
				}
				else {
					typing_layout.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		typing1.addChildEventListener(_typing1_child_listener);
		
		_typing2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		typing2.addChildEventListener(_typing2_child_listener);
		
		_sdb_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_sdb_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_sdb_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				_com();
				mkey = chat1.push().getKey();
				cc = Calendar.getInstance();
				map = new HashMap<>();
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("message_type", "AUDIO");
				map.put("audio_url", _downloadUrl);
				map.put("audio_played", "false");
				map.put("audio_time", (int)(pushAadT));
				map.put("mkey", mkey);
				map.put("message_status", "forwarded");
				chat1.child(mkey).updateChildren(map);
				chat2.child(mkey).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("seconduser"));
				map.put("lastMessage", "Voice 🔊 ".concat(waktu.concat(String.valueOf((long)(pushAadT)))));
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
				map.put("read", "");
				ms.child(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser")))).updateChildren(map);
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("firstuser"));
				map.put("lastMessage", "Voice 🔊 ".concat(waktu.concat(String.valueOf((long)(pushAadT)))));
				map.put("typing", "false");
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
				map.put("read", "");
				ms.child(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser")))).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("typing", "false");
				typing2.child("typing_status").updateChildren(map);
				map.clear();
				progd.dismiss();
				AudioTime = 0;
				pushAadT = 0;
				send_message = MediaPlayer.create(getApplicationContext(), R.raw.app_src_main_res_raw_sound_in);
				send_message.start();
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					HEADERS = new HashMap<>();
					HEADERS.put("Authorization", "key=".concat(Server_key));
					HEADERS.put("Content-Type", "application/json");
					Notification_BODY = new HashMap<>();
					Notification_BODY.put("body", "Sound");
					Notification_BODY.put("title", username.getText().toString());
					Notification_BODY.put("image", img_user_url.getText().toString());
					BODY = new HashMap<>();
					BODY.put("to", token_user.getText().toString());
					SketchwareUtil.showMessage(getApplicationContext(), "Sending To FCM TOKEN");
					BODY.put("notification", Notification_BODY);
					RQ.setHeaders(HEADERS);
					RQ.setParams(BODY, RequestNetworkController.REQUEST_BODY);
					RQ.startRequestNetwork(RequestNetworkController.POST, URL, "A", _RQ_request_listener);
				}
				else {
					
				}
			}
		};
		
		_sdb_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_sdb_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_sdb_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_idb_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_idb_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_idb_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				mkey = chat1.push().getKey();
				cc = Calendar.getInstance();
				map = new HashMap<>();
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("message_type", "IMG");
				map.put("image_url", _downloadUrl);
				map.put("mkey", mkey);
				map.put("message_status", "forwarded");
				chat1.child(mkey).updateChildren(map);
				chat2.child(mkey).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("seconduser"));
				map.put("lastMessage", "🎑 IMAGE");
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				ms.child(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser")))).updateChildren(map);
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("firstuser"));
				map.put("lastMessage", "🎑 IMAGE");
				map.put("typing", "false");
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				ms.child(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser")))).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("typing", "false");
				typing2.child("typing_status").updateChildren(map);
				map.clear();
				img_pslyer = MediaPlayer.create(getApplicationContext(), R.raw.app_src_main_res_raw_sound_in);
				img_pslyer.start();
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					HEADERS = new HashMap<>();
					HEADERS.put("Authorization", "key=".concat(Server_key));
					HEADERS.put("Content-Type", "application/json");
					Notification_BODY = new HashMap<>();
					Notification_BODY.put("body", "Image");
					Notification_BODY.put("title", username.getText().toString());
					Notification_BODY.put("image", img_user_url.getText().toString());
					BODY = new HashMap<>();
					BODY.put("to", token_user.getText().toString());
					SketchwareUtil.showMessage(getApplicationContext(), "Sending To FCM TOKEN");
					BODY.put("notification", Notification_BODY);
					RQ.setHeaders(HEADERS);
					RQ.setParams(BODY, RequestNetworkController.REQUEST_BODY);
					RQ.startRequestNetwork(RequestNetworkController.POST, URL, "A", _RQ_request_listener);
				}
				else {
					
				}
				progd.dismiss();
			}
		};
		
		_idb_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_idb_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_idb_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_rq_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_inbox_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("uid").toString().equals(getIntent().getStringExtra("seconduser"))) {
					if (_childValue.containsKey("count")) {
						count = _childValue.get("count").toString();
					}
					else {
						count = "0";
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("uid").toString().equals(getIntent().getStringExtra("seconduser"))) {
					if (_childValue.containsKey("count")) {
						count = _childValue.get("count").toString();
					}
					else {
						count = "0";
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		inbox.addChildEventListener(_inbox_child_listener);
		
		_fdb_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "your file is uploading Please wait .");
			}
		};
		
		_fdb_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fdb_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				mkey = chat1.push().getKey();
				cc = Calendar.getInstance();
				map = new HashMap<>();
				map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("message_type", "FILE");
				map.put("file_url", _downloadUrl);
				map.put("mkey", mkey);
				map.put("message", DocName);
				map.put("file_size", returnedSize);
				map.put("file_format", format);
				map.put("message_status", "forwarded");
				chat1.child(mkey).updateChildren(map);
				chat2.child(mkey).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("seconduser"));
				map.put("lastMessage", "📄 File");
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
				map.put("read", "null");
				ms.child(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser")))).updateChildren(map);
				map = new HashMap<>();
				map.put("uid", getIntent().getStringExtra("firstuser"));
				map.put("lastMessage", "📄 File");
				map.put("typing", "false");
				map.put("myuid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("timestamp", String.valueOf((long)(cc.getTimeInMillis())));
				map.put("count", String.valueOf((long)(Double.parseDouble(count) + 1)));
				map.put("read", "null");
				ms.child(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser")))).updateChildren(map);
				map.clear();
				map = new HashMap<>();
				map.put("typing", "false");
				typing2.child("typing_status").updateChildren(map);
				map.clear();
				file_player = MediaPlayer.create(getApplicationContext(), R.raw.app_src_main_res_raw_sound_in);
				file_player.start();
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					HEADERS = new HashMap<>();
					HEADERS.put("Authorization", "key=".concat(Server_key));
					HEADERS.put("Content-Type", "application/json");
					Notification_BODY = new HashMap<>();
					Notification_BODY.put("body", "File");
					Notification_BODY.put("title", username.getText().toString());
					Notification_BODY.put("image", img_user_url.getText().toString());
					BODY = new HashMap<>();
					BODY.put("to", token_user.getText().toString());
					SketchwareUtil.showMessage(getApplicationContext(), "Sending To FCM TOKEN");
					BODY.put("notification", Notification_BODY);
					RQ.setHeaders(HEADERS);
					RQ.setParams(BODY, RequestNetworkController.REQUEST_BODY);
					RQ.startRequestNetwork(RequestNetworkController.POST, URL, "A", _RQ_request_listener);
				}
				else {
					
				}
			}
		};
		
		_fdb_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "download successful ");
			}
		};
		
		_fdb_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fdb_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_t_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("hzr").toString().equals("true")) {
					warning_layout.setVisibility(View.VISIBLE);
					message_body.setVisibility(View.GONE);
					messages.setVisibility(View.GONE);
					textview1.setVisibility(View.VISIBLE);
				}
				else {
					if (_childValue.get("hzr").toString().equals("false")) {
						message_body.setVisibility(View.VISIBLE);
						warning_layout.setVisibility(View.GONE);
						messages.setVisibility(View.VISIBLE);
						textview1.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		t.addChildEventListener(_t_child_listener);
		
		_RQ_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		Cm_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				FirebaseInstanceId.getInstance().getInstanceId()
				                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
						        @Override
						        public void onComplete(@NonNull Task<InstanceIdResult> task) {
								            if (task.isSuccessful()) {
							token = task.getResult().getToken();
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), task.getException() != null ? task.getException().getMessage() : "");
						}
								        }
						    });
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		AXEmojiManager.install(ChatActivity.this,new com.aghajari.emojiview.emoji.iosprovider.AXIOSEmojiProvider(ChatActivity.this));
		
		AXEmojiManager.getEmojiViewTheme().setFooterEnabled(true);
		
		AXEmojiPager emojiPager = new AXEmojiPager(ChatActivity.this);
		
		AXEmojiView emojiView = new AXEmojiView(ChatActivity.this);
		emojiPager.addPage(emojiView, R.drawable.outline_insert_emoticon_black_48dp);
		
		emojiPager.setEditText(message);
		
		emojiPager.setLeftIcon(R.drawable.outline_search_black_48dp);
		
		AXEmojiPopupLayout layout = findViewById(R.id.layout);
		layout.setPopupAnimationEnabled(true);
		layout.setPopupAnimationDuration(250);
		layout.initPopupView(emojiPager);
		
		send.setVisibility(View.GONE);
		warning_layout.setVisibility(View.GONE);
		FilePath = FileUtil.getExternalStorageDir().concat("/Unilove/Files/");
		if (!FileUtil.isExistFile(FilePath)) {
			FileUtil.makeDir(FilePath);
		}
		count = "0";
		_DataBaseCustom();
		
		AudioRecording = true;
		ReplyedBoolean = false;
		loader.setVisibility(View.VISIBLE);
		sound_record_body.setVisibility(View.GONE);
		category.setVisibility(View.GONE);
		textview1.setVisibility(View.GONE);
		typing_layout.setVisibility(View.GONE);
		messages.setStackFromBottom(true);
		verified.setVisibility(View.GONE);
		message_body_in_reply.setVisibility(View.GONE);
		AudioPath = FileUtil.getPackageDataDir(getApplicationContext()).concat("/".concat("record.mp3"));
	}
	
	private MediaRecorder myAudioRecorder;
	
	private void fo4o() {
		username.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
		URL = "https://fcm.googleapis.com/fcm/send";
		Server_key = "AAAADi05lYY:APA91bFciRoYjD3OD1aZ-tpCHjblJHFjF2WJXZgKcgvs34fopRT2J4_0o2f8fUf1hBodkEIaZhnXpr92wxh91audVwxHEAHKwrEnaG9XvygoQFzVD9Wv96JV7p2vOd8i8Gu7yh_DYbL3";
		/*How to get Server_key?

Go to Firebase console — →Project Settings — →Cloud Messaging.*/
		FirebaseInstanceId.getInstance().getInstanceId()
		                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
				        @Override
				        public void onComplete(@NonNull Task<InstanceIdResult> task) {
						            if (task.isSuccessful()) {
					token = task.getResult().getToken();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Couldn't generate FCM TOKEN :\n".concat(task.getException() != null ? task.getException().getMessage() : ""));
					SketchwareUtil.showMessage(getApplicationContext(), "How to get Server_key?\n\nGo to Firebase console — →Project Settings — →Cloud Messaging.");
				}
						        }
				    });
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_IMG:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				
			}
			else {
				
			}
			break;
			
			case REQ_CD_DOC:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				DocPath = _filePath.get((int)(0));
				DocName = Uri.parse(DocPath).getLastPathSegment();
				_formatt();
				_CalculateSize(FileUtil.getFileLength(_filePath.get((int)(0))));
				fdb.child(DocName).putFile(Uri.fromFile(new File(DocPath))).addOnFailureListener(_fdb_failure_listener).addOnProgressListener(_fdb_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fdb.child(DocName).getDownloadUrl();
					}}).addOnCompleteListener(_fdb_upload_success_listener);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		map = new HashMap<>();
		map.put("typing", "false");
		typing2.child("typing_status").updateChildren(map);
		map.clear();
		chat1.removeEventListener(_chat1_child_listener);
		chat2.removeEventListener(_chat2_child_listener);
		finish();
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_ImageColor(back, "#000000");
		_ImageColor(more_button, "#000000");
		_ImageColor(media, "#000000");
		_ImageColor(sound, "#000000");
		username.setTextColor(0xFF000000);
		message.setTextColor(0xFF000000);
		warning_layout.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFEEEEEE));
		message_body.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFFEEEEEE));
		_rippleRoundStroke(send, "#673AB7", "#82B1FF", 100, 0, "#FFFFFF");
		_CustomView();
		_RippleRoundCustomView();
		_Language();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		map = new HashMap<>();
		map.put("typing", "false");
		typing2.child("typing_status").updateChildren(map);
		map.clear();
		chat1.removeEventListener(_chat1_child_listener);
		chat2.removeEventListener(_chat2_child_listener);
	}
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _ImageColor(final ImageView _image, final String _color) {
		_image.setColorFilter(Color.parseColor(_color),PorterDuff.Mode.SRC_ATOP);
	}
	
	
	public void _RippleRoundCustomView() {
		_rippleRoundStroke(profile, "#FFFFFF", "#BDBDBD", 8, 0, "#FFFFFF");
		_rippleRoundStroke(more_button, "#FFFFFF", "#BDBDBD", 100, 0, "#FFFFFF");
		_rippleRoundStroke(back, "#FFFFFF", "#BDBDBD", 100, 0, "#FFFFFF");
	}
	
	
	public void _DataBaseCustom() {
		chat1.removeEventListener(_chat1_child_listener);
		chat2.removeEventListener(_chat2_child_listener);
		chatroom = "chat/".concat(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser"))));
		chatcopy = "chat/".concat(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser"))));
		chat1 =
		_firebase.getReference(chatroom);
		chat2 =
		_firebase.getReference(chatcopy);
		chat1.addChildEventListener(_chat1_child_listener);
		chat2.addChildEventListener(_chat2_child_listener);
		typing1.removeEventListener(_typing1_child_listener);
		typing2.removeEventListener(_typing2_child_listener);
		typingview = "typing/".concat(getIntent().getStringExtra("firstuser").concat("/".concat(getIntent().getStringExtra("seconduser"))));
		typingcopy = "typing/".concat(getIntent().getStringExtra("seconduser").concat("/".concat(getIntent().getStringExtra("firstuser"))));
		typing1 =
		_firebase.getReference(typingview);
		typing2 =
		_firebase.getReference(typingcopy);
		typing1.addChildEventListener(_typing1_child_listener);
		typing2.addChildEventListener(_typing2_child_listener);
		inbox.removeEventListener(_inbox_child_listener);
		inboxx = "inbox/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		inbox =
		_firebase.getReference(inboxx);
		inbox.addChildEventListener(_inbox_child_listener);
	}
	
	
	public void _CustomView() {
		ReplyedBoolean = false;
		ChildAdded = false;
		top.setElevation((float)8);
		_ImageColor(send, "#FFFFFF");
	}
	
	
	public void _Language() {
		if (lang.getString("language", "").equals("")) {
			_TrLang();
		}
		if (lang.getString("language", "").equals("english")) {
			_EnLang();
		}
		if (lang.getString("language", "").equals("indonesia")) {
			_InLang();
		}
		if (lang.getString("language", "").equals("ar")) {
			_ar();
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			LinearLayout layout_progress = (LinearLayout)coreprog.findViewById(R.id.layout_progress);
			
			if (save.getString("theme", "").equals("gradient")) {
					android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
					gd.setColor(Color.parseColor("#FFFFFF")); /* color */
					gd.setCornerRadius(45); /* radius */
					gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
					linear2.setBackground(gd);
			}
			else {
					if (save.getString("theme", "").equals("light")) {
							android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
							gd.setColor(Color.parseColor("#FFFFFF")); /* color */
							gd.setCornerRadius(45); /* radius */
							gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
							linear2.setBackground(gd);
					}
					else {
							if (save.getString("theme", "").equals("dark")) {
									android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
									gd.setColor(Color.parseColor("#212121")); /* color */
									gd.setCornerRadius(45); /* radius */
									gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
									linear2.setBackground(gd);
							}
					}
			}
			
			RadialProgressView progress = new RadialProgressView(this);
			layout_progress.addView(progress);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _setTime(final double _currentTime, final TextView _txt) {
		tm_difference = ct.getTimeInMillis() - _currentTime;
		if (tm_difference < 60000) {
			if ((tm_difference / 1000) < 2) {
				_txt.setText(SetTimeAsecond);
			}
			else {
				_txt.setText(String.valueOf((long)(tm_difference / 1000)).concat(SetTimeSecond));
			}
		}
		else {
			if (tm_difference < (60 * 60000)) {
				if ((tm_difference / 60000) < 2) {
					_txt.setText(SetTimeAMinute);
				}
				else {
					_txt.setText(String.valueOf((long)(tm_difference / 60000)).concat(SetTimeMinute));
				}
			}
			else {
				if (tm_difference < (24 * (60 * 60000))) {
					if ((tm_difference / (60 * 60000)) < 2) {
						_txt.setText(String.valueOf((long)(tm_difference / (60 * 60000))).concat(SetTimeHours));
					}
					else {
						_txt.setText(String.valueOf((long)(tm_difference / (60 * 60000))).concat(SetTimeHours));
					}
				}
				else {
					if (tm_difference < (7 * (24 * (60 * 60000)))) {
						if ((tm_difference / (24 * (60 * 60000))) < 2) {
							_txt.setText(String.valueOf((long)(tm_difference / (24 * (60 * 60000)))).concat(SetTimeDays));
						}
						else {
							_txt.setText(String.valueOf((long)(tm_difference / (24 * (60 * 60000)))).concat(SetTimeDays));
						}
					}
					else {
						time2.setTimeInMillis((long)(_currentTime));
						_txt.setText(new SimpleDateFormat("dd MMM yyyy hh:mm").format(time2.getTime()));
					}
				}
			}
		}
	}
	
	
	public void _TrLang() {
		message.setHint("Mesaj Yaz");
		warning.setText("⛔ Bu kullanıcı engellendi!");
		image_title.setText("Resim");
		file_title.setText("Dosya");
		music_title.setText("Müzik");
		SetTimeAsecond = "Bir saniye önce";
		SetTimeSecond = " saniye önce";
		SetTimeAMinute = "Bir dakika önce";
		SetTimeMinute = " dakika önce";
		SetTimeHours = " saat önce";
		SetTimeDays = " gün önce";
		OnlineStatus = "Şu an aktif";
		OfflineStatus = "Çevrimdışı";
		TypingStatus = " Yazıyor...";
		AudioErrorL = "Hata!";
		AudioMinute = " Dakika";
		AudioSecond = " Saniye";
		videocall = "Görüntülü Ara";
		block_s = "Engelle";
		report_s = "Bildir";
		messagecopyed = "Mesaj Kopyalandı";
		emptymessage = "Boş Mesaj Gönderilemez";
		edited = "Düzenlendi!";
		uploading_audio = "Ses sunucuya yükleniyor...";
		uploading_image = "Resim sunucuya yükleniyor...";
		RecordingString = "●●●   Kaydediliyor...    ";
		YouReplyTo = "Yanıt Veriyorsun : ";
		YES = "Evet";
		NO = "Hayır";
		DeleteMessageDialogTitle = "BİLGİ";
		DeleteMessageDialogMessage = "Mesajı gerçekten silmek istediğinizden emin misiniz?";
		MessagePopupEdit = "Düzenle";
		MessagePopupReply = "Yanıtla";
		MessagePopupCopy = "Kopyala";
		MessagePopupDelete = "Sil";
	}
	
	
	public void _EnLang() {
		message.setHint("Write message");
		warning.setText("⛔ This user has been blocked!");
		image_title.setText("Image");
		file_title.setText("File");
		music_title.setText("Music");
		SetTimeAsecond = "One second ago";
		SetTimeSecond = " seconds ago";
		SetTimeAMinute = "One minute ago";
		SetTimeMinute = " minute ago";
		SetTimeHours = " hours ago";
		SetTimeDays = " days ago";
		OnlineStatus = "Active now";
		OfflineStatus = "Offline";
		TypingStatus = " is Typing...";
		AudioErrorL = "Error!";
		AudioMinute = " Minute";
		AudioSecond = " Second";
		videocall = "Video Call";
		block_s = "Block";
		report_s = "Report";
		messagecopyed = "Message Copied";
		emptymessage = "Empty Message Cannot Be Sent";
		edited = "Edited!";
		uploading_audio = "Uploading audio to server...";
		uploading_image = "The image is uploading to the server...";
		RecordingString = "●●●   Recording...    ";
		YouReplyTo = "You Reply To : ";
		YES = "Yes";
		NO = "No";
		DeleteMessageDialogTitle = "INFO";
		DeleteMessageDialogMessage = "Are you sure you really want to delete the message?";
		MessagePopupEdit = "Edit";
		MessagePopupReply = "Reply";
		MessagePopupCopy = "Copy";
		MessagePopupDelete = "Delete";
	}
	
	
	public void _SX_CornerRadius_4(final View _view, final String _color1, final String _color2, final double _str, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color1));
		
		gd.setStroke((int)_str, Color.parseColor(_color2));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n3,(int)_n3,(int)_n4,(int)_n4});
		
		_view.setBackground(gd);
		
		_view.setElevation(2);
	}
	
	
	public void _lib() {
	}
	private ReportUserBottomdialogFragmentDialogFragmentActivity ReportUserBottomdialogFragmentDialogFragmentActivityN;
	private FragmentManager ReportUserBottomdialogFragmentDialogFragmentActivityFM;
	public void test_ReportUserBottomdialogFragmentDialogFragmentActivity () {
	}
	
	
	public void _DeleteMessageDialog(final String _Title, final String _Message, final String _YesButtonText, final String _NoButtonText, final boolean _MultiButton) {
		final AlertDialog DeleteMessageDialog = new AlertDialog.Builder(ChatActivity.this).create();
		LayoutInflater DeleteMessageDialogLI = getLayoutInflater();
		View DeleteMessageDialogCV = (View) DeleteMessageDialogLI.inflate(R.layout.new_custom_dialog, null);
		DeleteMessageDialog.setView(DeleteMessageDialogCV);
		DeleteMessageDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final TextView dialog_title = (TextView)
		DeleteMessageDialogCV.findViewById(R.id.dialog_title);
		final TextView dialog_message = (TextView)
		DeleteMessageDialogCV.findViewById(R.id.dialog_message);
		final TextView dialog_no_button = (TextView)
		DeleteMessageDialogCV.findViewById(R.id.dialog_no_button);
		final TextView dialog_yes_button = (TextView)
		DeleteMessageDialogCV.findViewById(R.id.dialog_yes_button);
		_rippleRoundStroke(dialog_yes_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		_rippleRoundStroke(dialog_no_button, "#FFFFFF", "#CFD8DC", 6, 2, "#CFD8DC");
		dialog_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
		dialog_title.setText(_Title);
		dialog_message.setText(_Message);
		if (_MultiButton) {
			dialog_no_button.setText(_NoButtonText);
			dialog_no_button.setVisibility(View.VISIBLE);
		}
		else {
			dialog_no_button.setVisibility(View.GONE);
		}
		dialog_yes_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				chat1.child(save.getString("LastDeleteMessageKey", "")).removeValue();
				chat2.child(save.getString("LastDeleteMessageKey", "")).removeValue();
				DeleteMessageDialog.dismiss();
				
			}
		});
		dialog_no_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DeleteMessageDialog.dismiss();
				
			}
		});
		dialog_yes_button.setText(_YesButtonText);
		DeleteMessageDialog.setCancelable(true);
		DeleteMessageDialog.show();
	}
	
	
	public void _InLang() {
		message.setHint("Tulis Pesan");
		warning.setText("⛔ Pengguna ini telah diblokir!");
		image_title.setText("Gambar");
		file_title.setText("File");
		music_title.setText("Musik");
		SetTimeAsecond = "Satu detik lalu";
		SetTimeSecond = " detik lalu";
		SetTimeAMinute = "Satu menit lalu";
		SetTimeMinute = " menit lalu";
		SetTimeHours = " jam lalu";
		SetTimeDays = " Hari lalu";
		OnlineStatus = "Sedang Aktif";
		OfflineStatus = "Offline";
		TypingStatus = " Mengetik...";
		AudioErrorL = "Error!";
		AudioMinute = " Menit";
		AudioSecond = " Detik";
		videocall = "Video Call";
		block_s = "Blokir";
		report_s = "Laporkan";
		messagecopyed = "Pesan Disalin";
		emptymessage = "Tidak dapat mengirim pesan kosong";
		edited = "Diedit!";
		uploading_audio = "Mengupload audio ke server...";
		uploading_image = "Gambar sedang di upload ke  server...";
		RecordingString = "●●●   Merekam...    ";
		YouReplyTo = "Kamu Membalas ke : ";
		YES = "Iya";
		NO = "Tidak";
		DeleteMessageDialogTitle = "INFO";
		DeleteMessageDialogMessage = "Kamu yakin ingin menghapus pesan?";
		MessagePopupEdit = "Edit";
		MessagePopupReply = "Balas";
		MessagePopupCopy = "Salin";
		MessagePopupDelete = "Hapus";
	}
	
	
	public void _com() {
		if (pushAadT < 10) {
			waktu = "0.0";
		}
		else {
			waktu = "0.";
		}
	}
	
	
	public void _CalculateSize(final double _fileSize) {
		B = 1024;
		KB = B * B;
		MB = B * (B * B);
		GB = B * (B * (B * B));
		TB = B * (B * (B * (B * B)));
		PB = B * (B * (B * (B * (B * B))));
		if (_fileSize < B) {
			returnedSize = String.valueOf((long)(_fileSize)).concat(" B");
		}
		else {
			if (_fileSize < KB) {
				returnedSize = new DecimalFormat("0.00").format(_fileSize / B).concat(" KB");
			}
			else {
				if (_fileSize < MB) {
					returnedSize = new DecimalFormat("0.00").format(_fileSize / KB).concat(" MB");
				}
				else {
					if (_fileSize < GB) {
						returnedSize = new DecimalFormat("0.00").format(_fileSize / MB).concat(" GB");
					}
					else {
						if (_fileSize < TB) {
							returnedSize = new DecimalFormat("0.00").format(_fileSize / GB).concat(" TB");
						}
						else {
							if (_fileSize < PB) {
								returnedSize = new DecimalFormat("0.00").format(_fileSize / TB).concat(" PB");
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _formatt() {
		if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("mp3").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".mp3")) {
			format = "MP3";
		}
		else {
			if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("apk").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".apk")) {
				format = "APK";
			}
			else {
				if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("jpg").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".jpg")) {
					format = "JPG";
				}
				else {
					if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("png").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".png")) {
						format = "PNG";
					}
					else {
						if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("mp4").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".mp4")) {
							format = "MP4";
						}
						else {
							if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("html").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".html")) {
								format = "HTML";
							}
							else {
								if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("css").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".css")) {
									format = "CSS";
								}
								else {
									if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("pdf").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".pdf")) {
										format = "PDF";
									}
									else {
										if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("zip").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".zip")) {
											format = "ZIP";
										}
										else {
											if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("rar").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".rar")) {
												format = "RAR";
											}
											else {
												if (Uri.parse(DocPath).getLastPathSegment().substring((int)(Uri.parse(DocPath).getLastPathSegment().length() - ".".concat("json").length()), (int)(Uri.parse(DocPath).getLastPathSegment().length())).equals(".json")) {
													format = "JSON";
												}
												else {
													format = "UNKNOWN";
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _reGenerateToken() {
		FirebaseInstanceId.getInstance().getInstanceId()
		                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
				        @Override
				        public void onComplete(@NonNull Task<InstanceIdResult> task) {
						            if (task.isSuccessful()) {
					token = task.getResult().getToken();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Couldn't generate FCM TOKEN :\n".concat(task.getException() != null ? task.getException().getMessage() : ""));
				}
						        }
				    });
	}
	
	
	public void _ar() {
		message.setHint("اكتب رسالة");
		warning.setText("محظور");
		image_title.setText("صور");
		file_title.setText("ملفات");
		music_title.setText("صوت");
		SetTimeAsecond = "ثانية";
		SetTimeSecond = "منذ ثواني";
		SetTimeAMinute = "دقيقه";
		SetTimeMinute = "منذ دقيقه";
		SetTimeHours = " منذ ساعات";
		SetTimeDays = " منذ ايام";
		OnlineStatus = "متصل";
		OfflineStatus = "غير متصل";
		TypingStatus = " يكتب...";
		AudioErrorL = "خطأ!";
		AudioMinute = " دقيقة ";
		AudioSecond = " ثانية";
		videocall = "مكالمة فيديو";
		block_s = "حظر";
		report_s = "تقرير ";
		messagecopyed = "تم نسخ الرسالة";
		edited = "تم التعديل";
		uploading_audio = "جارٍ تحميل الصوت إلى الخادم...";
		RecordingString = "●●● التسجيل...";
		YouReplyTo = "أنت ترد على :";
		YES = "نعم";
		NO = "لا";
		DeleteMessageDialogTitle = "تفاصيل ";
		DeleteMessageDialogMessage = "هل أنت متأكد من أنك تريد حقًا حذف الرسالة؟";
		MessagePopupEdit = "تعديل";
		MessagePopupReply = "رد";
		MessagePopupCopy = "نسخ";
		MessagePopupDelete = "حذف";
	}
	
	public class MessagesAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public MessagesAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.message, null);
			}
			
			final LinearLayout body = _view.findViewById(R.id.body);
			final LinearLayout message_mn = _view.findViewById(R.id.message_mn);
			final LinearLayout message_layout = _view.findViewById(R.id.message_layout);
			final LinearLayout reply = _view.findViewById(R.id.reply);
			final TextView message_text = _view.findViewById(R.id.message_text);
			final LinearLayout linear_file = _view.findViewById(R.id.linear_file);
			final LinearLayout audio_play_layout = _view.findViewById(R.id.audio_play_layout);
			final androidx.cardview.widget.CardView image_card = _view.findViewById(R.id.image_card);
			final LinearLayout date_time_seen = _view.findViewById(R.id.date_time_seen);
			final LinearLayout reply_wt_box = _view.findViewById(R.id.reply_wt_box);
			final LinearLayout reply_in_info = _view.findViewById(R.id.reply_in_info);
			final TextView reply_in_username = _view.findViewById(R.id.reply_in_username);
			final TextView reply_in_message = _view.findViewById(R.id.reply_in_message);
			final ImageView im_file = _view.findViewById(R.id.im_file);
			final TextView tx_file_name = _view.findViewById(R.id.tx_file_name);
			final ImageView download = _view.findViewById(R.id.download);
			final ImageView play_pause = _view.findViewById(R.id.play_pause);
			final TextView audio_time = _view.findViewById(R.id.audio_time);
			final ImageView image_ = _view.findViewById(R.id.image_);
			final TextView format_file = _view.findViewById(R.id.format_file);
			final TextView date = _view.findViewById(R.id.date);
			final ImageView status = _view.findViewById(R.id.status);
			
			format_file.setVisibility(View.GONE);
			if (_data.get((int)_position).containsKey("message_type")) {
				if (_data.get((int)_position).containsKey("replyed_message")) {
					reply.setVisibility(View.VISIBLE);
					reply_in_username.setText(UserName.get(_data.get((int)_position).get("replyed_message_uid").toString()).toString());
					reply_in_message.setText(_data.get((int)_position).get("replyed_message").toString());
				}
				else {
					reply.setVisibility(View.GONE);
				}
				if (_data.get((int)_position).get("message_type").toString().equals("MSG")) {
					image_card.setVisibility(View.GONE);
					audio_play_layout.setVisibility(View.GONE);
					message_text.setVisibility(View.VISIBLE);
					message_text.setText(_data.get((int)_position).get("message").toString());
					linear_file.setVisibility(View.GONE);
				}
				if (_data.get((int)_position).get("message_type").toString().equals("IMG")) {
					image_card.setVisibility(View.VISIBLE);
					audio_play_layout.setVisibility(View.GONE);
					message_text.setVisibility(View.GONE);
					linear_file.setVisibility(View.GONE);
					Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("image_url").toString())).into(image_);
					image_card.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							intent.putExtra("image", _data.get((int)_position).get("image_url").toString());
							intent.putExtra("username", UserName.get(getIntent().getStringExtra("seconduser")).toString());
							intent.putExtra("uid", getIntent().getStringExtra("seconduser"));
							intent.putExtra("date", _data.get((int)_position).get("timestamp").toString());
							intent.setClass(getApplicationContext(), StoryviewActivity.class);
							startActivity(intent);
						}
					});
				}
				if (_data.get((int)_position).get("message_type").toString().equals("FILE")) {
					image_card.setVisibility(View.GONE);
					audio_play_layout.setVisibility(View.GONE);
					message_text.setVisibility(View.GONE);
					linear_file.setVisibility(View.VISIBLE);
					format_file.setVisibility(View.VISIBLE);
					tx_file_name.setText(_data.get((int)_position).get("message").toString());
					if (_data.get((int)_position).containsKey("file_size")) {
						format_file.setText(_data.get((int)_position).get("file_size").toString().concat(" • ".concat(Uri.parse(_data.get((int)_position).get("file_format").toString()).getLastPathSegment())));
					}
					if (FileUtil.isExistFile(FilePath.concat(_data.get((int)_position).get("message").toString()))) {
						download.setVisibility(View.GONE);
					}
					else {
						download.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								download.setVisibility(View.GONE);
								_firebase_storage.getReferenceFromUrl(_data.get((int)_position).get("file_url").toString()).getFile(new File(FilePath.concat(_data.get((int)_position).get("message").toString()))).addOnSuccessListener(_fdb_download_success_listener).addOnFailureListener(_fdb_failure_listener).addOnProgressListener(_fdb_download_progress_listener);
							}
						});
					}
				}
				if (_data.get((int)_position).get("message_type").toString().equals("AUDIO")) {
					image_card.setVisibility(View.GONE);
					audio_play_layout.setVisibility(View.VISIBLE);
					message_text.setVisibility(View.GONE);
					linear_file.setVisibility(View.GONE);
					play_pause.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									try {
											play_pause.setImageResource(R.drawable.round_pause_circle_white_48dp);
											audioUrl = _data.get((int)_position).get("audio_url").toString();
											if (isPlaying) {
													if (audio.isPlaying()) {
															audio.stop();
													}
											}
											else {
													isPlaying = true;
											}
											audio = new MediaPlayer();
											audio.setAudioStreamType(3);
											try {
													audio.setDataSource(audioUrl);
											}catch (IllegalArgumentException e) {
													Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show();
											} catch (SecurityException e2) {
													Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); }
											catch (IllegalStateException e3) {
													Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); }
											catch (java.io.IOException e4)
											{
													e4.printStackTrace();
											}
											try
											{
													audio.prepare();
											}
											catch (IllegalStateException e5)
											{
													Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show();
											}
											catch (java.io.IOException e6)
											{
													Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show();
											}
											audio.start();
											audiotimer = new TimerTask() {
													@Override
													public void run() {
															runOnUiThread(new Runnable() {
																	@Override
																	public void run() {
																			if (audio.isPlaying()) {
																					play_pause.setImageResource(R.drawable.round_pause_circle_white_48dp);
																					isPlaying = true;
																			}
																			else {
																					play_pause.setImageResource(R.drawable.round_play_circle_white_48dp);
																					audiotimer.cancel();
																			}
																	}
															});
													}
											};
											_timer.scheduleAtFixedRate(audiotimer, (int)(0), (int)(100));
											limit = _position;
											audio.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
													
													public void onCompletion(MediaPlayer theMediaPlayer){
															position_++;
													}
											});
									} catch (Exception e) {
											
									}
							}
					});
					
					if (_data.get((int)_position).containsKey("audio_time")) {
						if (Double.parseDouble(_data.get((int)_position).get("audio_time").toString()) < 60) {
								audio_time.setText(_data.get((int)_position).get("audio_time").toString().concat(AudioSecond));
						}
						else {
								if (Double.parseDouble(_data.get((int)_position).get("audio_time").toString()) == 60) {
										audio_time.setText(String.valueOf(Double.parseDouble(_data.get((int)_position).get("audio_time").toString()) / 60).concat(AudioMinute));
								}
								else {
										if (Double.parseDouble(_data.get((int)_position).get("audio_time").toString()) > 60) {
												audio_time.setText(String.valueOf(Double.parseDouble(_data.get((int)_position).get("audio_time").toString()) / 60).concat(AudioMinute));
										}
										else {
												audio_time.setText(AudioErrorL);
										}
								}
						}
						
					}
					else {
						audio_time.setText(AudioErrorL);
					}
				}
				if (_data.get((int)_position).containsKey("timestamp")) {
					cc.setTimeInMillis((long)(Double.parseDouble(_data.get((int)_position).get("timestamp").toString())));
					date.setText(new SimpleDateFormat("HH:mm").format(cc.getTime()));
				}
				if (_data.get((int)_position).get("message_status").toString().equals("forwarded")) {
					status.setImageResource(R.drawable.ic_done_black);
				}
				else {
					if (_data.get((int)_position).get("message_status").toString().equals("seen")) {
						status.setImageResource(R.drawable.ic_done_all_black);
					}
				}
				if (_data.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					status.setVisibility(View.VISIBLE);
					body.setGravity(Gravity.TOP | Gravity.RIGHT);
					message_mn.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					date_time_seen.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					_ImageColor(play_pause, "#FFFFFF");
					_ImageColor(status, "#FFFFFF");
					audio_time.setTextColor(0xFFFFFFFF);
					message_text.setTextColor(0xFFFFFFFF);
					date.setTextColor(0xFFFFFFFF);
					reply_wt_box.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFEEEEEE));
					reply_in_username.setTextColor(0xFFFFFFFF);
					reply_in_message.setTextColor(0xFFFFFFFF);
					format_file.setTextColor(0xFFFFFFFF);
					tx_file_name.setTextColor(0xFFFFFFFF);
					linear_file.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFF7E57C2));
					_ImageColor(download, "#FFFFFF");
					if (_position == 0) {
							_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 10, 20);
							if (listmap.size() == 1) {
									_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 20, 20);
							}
							else {
									if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
											_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 20, 20);
									}
							}
					}
					else {
							if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString())) {
									_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 10, 20);
									if (_position == (listmap.size() - 1)) {
											_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 20, 20);
									}
									else {
											if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 20, 20);
											}
									}
							}
							else {
									if (_position == (listmap.size() - 1)) {
											if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 10, 20, 20);
											}
											else {
													_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 20, 20);
											}
									}
									else {
											if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString()) && listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 10, 10, 20);
											}
											else {
													if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
															_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 20, 10, 20);
													}
													else {
															_SX_CornerRadius_4(message_layout, "#673AB7", "#008dcd", 0, 20, 10, 20, 20);
													}
											}
									}
							}
					}
				}
				else {
					status.setVisibility(View.GONE);
					body.setGravity(Gravity.TOP | Gravity.LEFT);
					message_mn.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					date_time_seen.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					_ImageColor(play_pause, "#000000");
					audio_time.setTextColor(0xFF000000);
					message_text.setTextColor(0xFF000000);
					date.setTextColor(0xFF000000);
					reply_wt_box.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFF6200EA));
					reply_in_username.setTextColor(0xFF673AB7);
					reply_in_message.setTextColor(0xFF000000);
					linear_file.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE0E0E0));
					format_file.setTextColor(0xFF000000);
					tx_file_name.setTextColor(0xFF000000);
					_ImageColor(download, "#000000");
					if (_position == 0) {
							_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 10);
							if (listmap.size() == 1) {
							}
							else {
									if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
											_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 20);
									}
							}
					}
					else {
							if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString())) {
									_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 10);
									if (_position == (listmap.size() - 1)) {
											_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 20);
									}
									else {
											if (!listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 20);
											}
									}
							}
							else {
									if (_position == (listmap.size() - 1)) {
											if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 10, 20, 20, 20);
											}
											else {
													_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 20);
											}
									}
									else {
											if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position - 1).get("uid").toString()) && listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
													_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 10, 20, 20, 10);
											}
											else {
													if (listmap.get((int)_position).get("uid").toString().equals(listmap.get((int)_position + 1).get("uid").toString())) {
															_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 20, 20, 20, 10);
													}
													else {
															_SX_CornerRadius_4(message_layout, "#FFFFFF", "#F5F5F5", 0, 10, 20, 20, 20);
													}
											}
									}
							}
					}
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}