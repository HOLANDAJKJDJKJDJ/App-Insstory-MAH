package com.mah.insstory.MAH;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aghajari.emojiview.*;
import com.facebook.shimmer.*;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import org.json.*;

public class LanguagesActivity extends AppCompatActivity {
	
	private String fontName = "";
	private String typeace = "";
	
	private ScrollView vscroll1;
	private LinearLayout body;
	private CardView top;
	private LinearLayout linear2;
	private LinearLayout english;
	private LinearLayout linear1;
	private LinearLayout turkish;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear7;
	private LinearLayout top_;
	private ImageView cancel;
	private TextView title;
	private ImageView save;
	private TextView textview2;
	private CheckBox checkbox1;
	private TextView english_title;
	private CheckBox checkbox2;
	private TextView textview1;
	private CheckBox checkbox3;
	private TextView turkish_title;
	private CheckBox checkbox4;
	private TextView textview3;
	private CheckBox checkbox5;
	private TextView textview4;
	private CheckBox checkbox6;
	private TextView textview5;
	private CheckBox checkbox7;
	private TextView textview6;
	private CheckBox checkbox8;
	private TextView textview10;
	private CheckBox checkbox9;
	private TextView textview11;
	private CheckBox checkbox10;
	private TextView textview7;
	private CheckBox checkbox11;
	
	private SharedPreferences lang;
	private Intent intent = new Intent();
	private SharedPreferences save1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.languages);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		body = findViewById(R.id.body);
		top = findViewById(R.id.top);
		linear2 = findViewById(R.id.linear2);
		english = findViewById(R.id.english);
		linear1 = findViewById(R.id.linear1);
		turkish = findViewById(R.id.turkish);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear7 = findViewById(R.id.linear7);
		top_ = findViewById(R.id.top_);
		cancel = findViewById(R.id.cancel);
		title = findViewById(R.id.title);
		save = findViewById(R.id.save);
		textview2 = findViewById(R.id.textview2);
		checkbox1 = findViewById(R.id.checkbox1);
		english_title = findViewById(R.id.english_title);
		checkbox2 = findViewById(R.id.checkbox2);
		textview1 = findViewById(R.id.textview1);
		checkbox3 = findViewById(R.id.checkbox3);
		turkish_title = findViewById(R.id.turkish_title);
		checkbox4 = findViewById(R.id.checkbox4);
		textview3 = findViewById(R.id.textview3);
		checkbox5 = findViewById(R.id.checkbox5);
		textview4 = findViewById(R.id.textview4);
		checkbox6 = findViewById(R.id.checkbox6);
		textview5 = findViewById(R.id.textview5);
		checkbox7 = findViewById(R.id.checkbox7);
		textview6 = findViewById(R.id.textview6);
		checkbox8 = findViewById(R.id.checkbox8);
		textview10 = findViewById(R.id.textview10);
		checkbox9 = findViewById(R.id.checkbox9);
		textview11 = findViewById(R.id.textview11);
		checkbox10 = findViewById(R.id.checkbox10);
		textview7 = findViewById(R.id.textview7);
		checkbox11 = findViewById(R.id.checkbox11);
		lang = getSharedPreferences("lang", Activity.MODE_PRIVATE);
		save1 = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		english.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		turkish.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		cancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (checkbox1.isChecked()) {
					lang.edit().putString("language", "ar").commit();
				}
				else {
					if (checkbox2.isChecked()) {
						lang.edit().putString("language", "en").commit();
					}
					else {
						if (checkbox3.isChecked()) {
							lang.edit().putString("language", "indnsia").commit();
						}
						else {
							if (checkbox4.isChecked()) {
								lang.edit().putString("language", "tr").commit();
							}
							else {
								if (checkbox5.isChecked()) {
									lang.edit().putString("language", "rosia").commit();
								}
								else {
									if (checkbox6.isChecked()) {
										lang.edit().putString("language", "ind").commit();
									}
									else {
										if (checkbox7.isChecked()) {
											lang.edit().putString("language", "sin").commit();
										}
										else {
											if (checkbox8.isChecked()) {
												lang.edit().putString("language", "etlia").commit();
											}
											else {
												if (checkbox9.isChecked()) {
													lang.edit().putString("language", "fransa").commit();
												}
												else {
													if (checkbox10.isChecked()) {
														lang.edit().putString("language", "elmania").commit();
													}
													else {
														if (checkbox11.isChecked()) {
															lang.edit().putString("language", "esbania").commit();
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				finish();
			}
		});
		
		checkbox1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(true);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(true);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(true);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(true);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(true);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(true);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(true);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(true);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(true);
				checkbox10.setChecked(false);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(true);
				checkbox11.setChecked(false);
			}
		});
		
		checkbox11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				checkbox1.setChecked(false);
				checkbox2.setChecked(false);
				checkbox3.setChecked(false);
				checkbox4.setChecked(false);
				checkbox5.setChecked(false);
				checkbox6.setChecked(false);
				checkbox7.setChecked(false);
				checkbox8.setChecked(false);
				checkbox9.setChecked(false);
				checkbox10.setChecked(false);
				checkbox11.setChecked(true);
			}
		});
	}
	
	private void initializeLogic() {
		title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
	}
	
	@Override
	public void onStart() {
		super.onStart();
		_ThemeCustom();
		_Language();
	}
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _ImageColor(final ImageView _image, final String _color) {
		_image.setColorFilter(Color.parseColor(_color),PorterDuff.Mode.SRC_ATOP);
	}
	
	
	public void _Language() {
		if (lang.getString("language", "").equals("")) {
			_TrLang();
		}
		if (lang.getString("language", "").equals("english")) {
			_EnLang();
		}
		if (lang.getString("language", "").equals("indonesia")) {
			_InLang();
		}
		if (lang.getString("language", "").equals("ar")) {
			_ar();
		}
	}
	
	
	public void _ThemeCustom() {
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		top.setBackgroundColor(0xFFFFFFFF);
		body.setBackgroundColor(0xFFFFFFFF);
		title.setTextColor(0xFF000000);
		english_title.setTextColor(0xFF000000);
		turkish_title.setTextColor(0xFF000000);
		_rippleRoundStroke(cancel, "#FFFFFF", "#BDBDBD", 100, 0, "#FFFFFF");
		_rippleRoundStroke(save, "#FFFFFF", "#BDBDBD", 100, 0, "#FFFFFF");
		_rippleRoundStroke(english, "#F5F5F5", "#BDBDBD", 20, 0, "#FFFFFF");
		_rippleRoundStroke(turkish, "#F5F5F5", "#BDBDBD", 20, 0, "#FFFFFF");
		_ImageColor(cancel, "#000000");
		_ImageColor(save, "#000000");
	}
	
	
	public void _TrLang() {
		checkbox1.setChecked(false);
		checkbox2.setChecked(false);
		checkbox2.setChecked(false);
		checkbox4.setChecked(true);
		checkbox5.setChecked(false);
		checkbox6.setChecked(false);
		checkbox7.setChecked(false);
		checkbox8.setChecked(false);
		checkbox9.setChecked(false);
		checkbox10.setChecked(false);
		checkbox11.setChecked(false);
	}
	
	
	public void _EnLang() {
		checkbox1.setChecked(false);
		checkbox2.setChecked(true);
		checkbox2.setChecked(false);
		checkbox4.setChecked(false);
		checkbox5.setChecked(false);
		checkbox6.setChecked(false);
		checkbox7.setChecked(false);
		checkbox8.setChecked(false);
		checkbox9.setChecked(false);
		checkbox10.setChecked(false);
		checkbox11.setChecked(false);
	}
	
	
	public void _InLang() {
		checkbox1.setChecked(false);
		checkbox2.setChecked(false);
		checkbox2.setChecked(true);
		checkbox4.setChecked(false);
		checkbox5.setChecked(false);
		checkbox6.setChecked(false);
		checkbox7.setChecked(false);
		checkbox8.setChecked(false);
		checkbox9.setChecked(false);
		checkbox10.setChecked(false);
		checkbox11.setChecked(false);
	}
	
	
	public void _ar() {
		checkbox1.setChecked(true);
		checkbox2.setChecked(false);
		checkbox2.setChecked(false);
		checkbox4.setChecked(false);
		checkbox5.setChecked(false);
		checkbox6.setChecked(false);
		checkbox7.setChecked(false);
		checkbox8.setChecked(false);
		checkbox9.setChecked(false);
		checkbox10.setChecked(false);
		checkbox11.setChecked(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}