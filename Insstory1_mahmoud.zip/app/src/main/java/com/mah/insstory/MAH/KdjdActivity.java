package com.mah.insstory.MAH;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.aghajari.emojiview.*;
import com.bumptech.glide.Glide;
import com.facebook.shimmer.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import org.json.*;

public class KdjdActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> map = new HashMap<>();
	
	private LinearLayout body;
	private LinearLayout top_layout;
	private ScrollView scroll;
	private TextView title;
	private LinearLayout scroll_in_body;
	private CircleImageView profile_image;
	private EditText name;
	private EditText username;
	private EditText biography;
	private LinearLayout red_verify;
	private LinearLayout blue_verify;
	private LinearLayout disable_verify;
	private LinearLayout ban_user;
	private LinearLayout reports;
	private LinearLayout live_support;
	private LinearLayout red_verify_check_layout;
	private TextView red_verify_subtext;
	private Button button1;
	private TextView red_verify_title;
	private CheckBox red_verify_check;
	private LinearLayout blue_verify_check_layout;
	private TextView blue_verify_subtext;
	private Button button2;
	private TextView blue_verify_title;
	private CheckBox blue_verify_check;
	private LinearLayout disable_verify_check_layout;
	private TextView disable_verify_subtext;
	private Button button3;
	private TextView disable_verify_title;
	private CheckBox disable_verify_check;
	private LinearLayout ban_user_check_layout;
	private TextView ban_user_subtext;
	private Button button4;
	private TextView ban_user_title;
	private CheckBox ban_user_check;
	private LinearLayout reports_check_layout;
	private TextView reports_subtext;
	private TextView reports_title;
	private ImageView reports_icon;
	private LinearLayout live_support_check_layout;
	private TextView live_support_subtext;
	private TextView live_support_title;
	private ImageView live_support_icon;
	
	private DatabaseReference udb = _firebase.getReference("users");
	private ChildEventListener _udb_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private SharedPreferences save;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.kdjd);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		MobileAds.initialize(this);
		
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		body = findViewById(R.id.body);
		top_layout = findViewById(R.id.top_layout);
		scroll = findViewById(R.id.scroll);
		title = findViewById(R.id.title);
		scroll_in_body = findViewById(R.id.scroll_in_body);
		profile_image = findViewById(R.id.profile_image);
		name = findViewById(R.id.name);
		username = findViewById(R.id.username);
		biography = findViewById(R.id.biography);
		red_verify = findViewById(R.id.red_verify);
		blue_verify = findViewById(R.id.blue_verify);
		disable_verify = findViewById(R.id.disable_verify);
		ban_user = findViewById(R.id.ban_user);
		reports = findViewById(R.id.reports);
		live_support = findViewById(R.id.live_support);
		red_verify_check_layout = findViewById(R.id.red_verify_check_layout);
		red_verify_subtext = findViewById(R.id.red_verify_subtext);
		button1 = findViewById(R.id.button1);
		red_verify_title = findViewById(R.id.red_verify_title);
		red_verify_check = findViewById(R.id.red_verify_check);
		blue_verify_check_layout = findViewById(R.id.blue_verify_check_layout);
		blue_verify_subtext = findViewById(R.id.blue_verify_subtext);
		button2 = findViewById(R.id.button2);
		blue_verify_title = findViewById(R.id.blue_verify_title);
		blue_verify_check = findViewById(R.id.blue_verify_check);
		disable_verify_check_layout = findViewById(R.id.disable_verify_check_layout);
		disable_verify_subtext = findViewById(R.id.disable_verify_subtext);
		button3 = findViewById(R.id.button3);
		disable_verify_title = findViewById(R.id.disable_verify_title);
		disable_verify_check = findViewById(R.id.disable_verify_check);
		ban_user_check_layout = findViewById(R.id.ban_user_check_layout);
		ban_user_subtext = findViewById(R.id.ban_user_subtext);
		button4 = findViewById(R.id.button4);
		ban_user_title = findViewById(R.id.ban_user_title);
		ban_user_check = findViewById(R.id.ban_user_check);
		reports_check_layout = findViewById(R.id.reports_check_layout);
		reports_subtext = findViewById(R.id.reports_subtext);
		reports_title = findViewById(R.id.reports_title);
		reports_icon = findViewById(R.id.reports_icon);
		live_support_check_layout = findViewById(R.id.live_support_check_layout);
		live_support_subtext = findViewById(R.id.live_support_subtext);
		live_support_title = findViewById(R.id.live_support_title);
		live_support_icon = findViewById(R.id.live_support_icon);
		auth = FirebaseAuth.getInstance();
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().equals("") || (username.getText().toString().equals("") || biography.getText().toString().equals(""))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Fill All Items");
				}
				else {
					map = new HashMap<>();
					if (red_verify_check.isChecked()) {
						map.put("verify", "red");
					}
					map.put("username", username.getText().toString());
					map.put("yourname", name.getText().toString());
					map.put("bio", biography.getText().toString());
					udb.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "Changes Saved!");
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().equals("") || (username.getText().toString().equals("") || biography.getText().toString().equals(""))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Fill All Items");
				}
				else {
					map = new HashMap<>();
					if (blue_verify_check.isChecked()) {
						map.put("verify", "blue");
					}
					map.put("username", username.getText().toString());
					map.put("yourname", name.getText().toString());
					map.put("bio", biography.getText().toString());
					udb.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "Changes Saved!");
				}
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().equals("") || (username.getText().toString().equals("") || biography.getText().toString().equals(""))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Fill All Items");
				}
				else {
					map = new HashMap<>();
					if (disable_verify_check.isChecked()) {
						map.put("verify", "false");
					}
					map.put("username", username.getText().toString());
					map.put("yourname", name.getText().toString());
					map.put("bio", biography.getText().toString());
					udb.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "Changes Saved!");
				}
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (name.getText().toString().equals("") || (username.getText().toString().equals("") || biography.getText().toString().equals(""))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Fill All Items");
				}
				else {
					map = new HashMap<>();
					if (ban_user_check.isChecked()) {
						map = new HashMap<>();
						map.put("blocked", "true");
					}
					else {
						map = new HashMap<>();
						map.put("blocked", "false");
					}
					map.put("username", username.getText().toString());
					map.put("yourname", name.getText().toString());
					map.put("bio", biography.getText().toString());
					udb.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "Changes Saved!");
				}
			}
		});
		
		_udb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(profile_image);
					name.setText(_childValue.get("yourname").toString());
					username.setText(_childValue.get("username").toString());
					biography.setText(_childValue.get("bio").toString());
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		udb.addChildEventListener(_udb_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}